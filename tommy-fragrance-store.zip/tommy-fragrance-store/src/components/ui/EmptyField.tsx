export function EmptyField() {
  return <span className="text-graphite-400">Нет подтверждённых данных</span>;
}

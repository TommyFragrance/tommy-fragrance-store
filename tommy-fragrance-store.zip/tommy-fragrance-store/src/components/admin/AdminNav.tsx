import Link from "next/link";

const items = [
  { href: "/admin", label: "Обзор" },
  { href: "/admin/products", label: "Товары" },
  { href: "/admin/products/new", label: "Добавить товар" },
  { href: "/admin/import", label: "Импорт" },
  { href: "/admin/orders", label: "Заказы" },
  { href: "/", label: "На сайт" }
];

export function AdminNav() {
  return (
    <aside className="rounded-[2rem] border border-graphite-100 bg-white p-4 shadow-soft">
      <div className="px-4 py-3 text-xs font-semibold uppercase tracking-luxury text-graphite-400">Admin</div>
      <nav className="grid gap-1">
        {items.map((item) => (
          <Link key={item.href} href={item.href} className="rounded-2xl px-4 py-3 text-sm font-medium text-graphite-700 transition hover:bg-graphite-50 hover:text-graphite-900">
            {item.label}
          </Link>
        ))}
      </nav>
    </aside>
  );
}

"use client";

import { FormEvent, useState } from "react";
import { signIn } from "next-auth/react";
import { useSearchParams } from "next/navigation";

export function LoginForm() {
  const params = useSearchParams();
  const callbackUrl = params.get("callbackUrl") || "/admin";
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const res = await signIn("credentials", {
      email: String(form.get("email")),
      password: String(form.get("password")),
      callbackUrl,
      redirect: false
    });
    if (res?.error) setError("Неверный email или пароль");
    if (res?.url) window.location.href = res.url;
  }

  return (
    <form onSubmit={onSubmit} className="w-full rounded-[2rem] border border-graphite-100 bg-white p-8 shadow-soft">
      <div className="text-xs font-semibold uppercase tracking-luxury text-graphite-400">Tommy Fragrance</div>
      <h1 className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-graphite-900">Вход в админку</h1>
      <div className="mt-8 grid gap-4">
        <input name="email" type="email" placeholder="Email" className="rounded-2xl border border-graphite-200 px-4 py-3 text-sm outline-none focus:border-graphite-900" />
        <input name="password" type="password" placeholder="Пароль" className="rounded-2xl border border-graphite-200 px-4 py-3 text-sm outline-none focus:border-graphite-900" />
        {error ? <div className="rounded-2xl bg-red-50 p-3 text-sm text-red-700">{error}</div> : null}
        <button className="btn-primary">Войти</button>
      </div>
    </form>
  );
}

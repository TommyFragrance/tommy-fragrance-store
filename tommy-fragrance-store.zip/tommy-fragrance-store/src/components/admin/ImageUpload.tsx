"use client";

import { useState } from "react";

export function ImageUpload({ defaultValue = "" }: { defaultValue?: string }) {
  const [url, setUrl] = useState(defaultValue);
  const [loading, setLoading] = useState(false);

  async function onFile(file: File) {
    const formData = new FormData();
    formData.append("file", file);
    setLoading(true);
    const res = await fetch("/api/admin/upload", { method: "POST", body: formData });
    const data = await res.json();
    setLoading(false);
    if (data.url) setUrl(data.url);
  }

  return (
    <div className="grid gap-2 md:col-span-2">
      <span className="text-xs font-semibold uppercase tracking-[0.16em] text-graphite-500">Фотография</span>
      <input name="imageUrl" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="/uploads/photo.webp или внешний URL" className="rounded-2xl border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900" />
      <input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} className="rounded-2xl border border-dashed border-graphite-200 bg-graphite-50 px-4 py-3 text-sm" />
      {loading ? <span className="text-xs text-graphite-400">Загрузка...</span> : null}
    </div>
  );
}

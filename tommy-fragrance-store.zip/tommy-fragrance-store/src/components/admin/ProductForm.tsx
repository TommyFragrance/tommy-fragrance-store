import type { Brand, Product } from "@prisma/client";
import { centsToRubInput } from "@/lib/utils";
import { saveProduct } from "@/app/admin/products/actions";
import { ImageUpload } from "@/components/admin/ImageUpload";

type ProductWithBrand = (Product & { brand: Brand }) | null;

function Field({ label, name, defaultValue, type = "text", placeholder }: { label: string; name: string; defaultValue?: string | number | null; type?: string; placeholder?: string }) {
  return (
    <label className="grid gap-2">
      <span className="text-xs font-semibold uppercase tracking-[0.16em] text-graphite-500">{label}</span>
      <input name={name} type={type} defaultValue={defaultValue ?? ""} placeholder={placeholder} className="rounded-2xl border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900" />
    </label>
  );
}

function Area({ label, name, defaultValue, placeholder }: { label: string; name: string; defaultValue?: string | null; placeholder?: string }) {
  return (
    <label className="grid gap-2 md:col-span-2">
      <span className="text-xs font-semibold uppercase tracking-[0.16em] text-graphite-500">{label}</span>
      <textarea name={name} defaultValue={defaultValue ?? ""} placeholder={placeholder} rows={5} className="rounded-2xl border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900" />
    </label>
  );
}

export function ProductForm({ product }: { product?: ProductWithBrand }) {
  return (
    <form action={saveProduct} className="grid gap-6 rounded-[2rem] border border-graphite-100 bg-white p-6 shadow-soft">
      {product?.id ? <input type="hidden" name="id" value={product.id} /> : null}
      <div className="grid gap-4 md:grid-cols-2">
        <Field label="Название" name="name" defaultValue={product?.name} placeholder="Matsukita" />
        <Field label="Бренд" name="brandName" defaultValue={product?.brand.name} placeholder="Clive Christian" />
        <Field label="Slug" name="slug" defaultValue={product?.slug} placeholder="оставь пустым — создастся автоматически" />
        <Field label="Год выпуска" name="year" type="number" defaultValue={product?.year} />
        <Field label="Парфюмер" name="perfumer" defaultValue={product?.perfumer} />
        <Field label="Концентрация" name="concentration" defaultValue={product?.concentration} placeholder="EDP / Parfum / Extrait" />
        <Field label="Страна бренда" name="brandCountry" defaultValue={product?.brandCountry} />
        <Field label="Пол" name="gender" defaultValue={product?.gender} placeholder="мужской / женский / унисекс" />
        <Field label="Тип аромата" name="aromaType" defaultValue={product?.aromaType} placeholder="древесный, амбровый..." />
        <Field label="Стойкость" name="longevity" defaultValue={product?.longevity} placeholder="только подтверждённые данные" />
        <Field label="Шлейф" name="sillage" defaultValue={product?.sillage} placeholder="только подтверждённые данные" />
        <Field label="Сезонность" name="seasonality" defaultValue={product?.seasonality.join(", ")} placeholder="осень, зима, вечер" />
        <Field label="Верхние ноты" name="topNotes" defaultValue={product?.topNotes.join(", ")} />
        <Field label="Ноты сердца" name="heartNotes" defaultValue={product?.heartNotes.join(", ")} />
        <Field label="Базовые ноты" name="baseNotes" defaultValue={product?.baseNotes.join(", ")} />
        <Field label="Похожие ароматы" name="similarAromas" defaultValue={product?.similarAromas.join(", ")} />
        <Field label="Источники" name="sources" defaultValue={product?.sources.join(", ")} placeholder="официальный сайт, Fragrantica, Parfumo" />
        <Field label="Цена за 1 мл, ₽" name="pricePerMl" type="number" defaultValue={centsToRubInput(product?.pricePerMlCents)} />
        <Field label="Объёмы распива, мл" name="availableVolumesMl" defaultValue={product?.availableVolumesMl.join(", ") || "1,2,3,5,10,15,20,30,50"} />
        <Field label="Объём полного флакона, мл" name="fullBottleMl" type="number" defaultValue={product?.fullBottleMl} />
        <Field label="Цена полного флакона, ₽" name="fullBottlePrice" type="number" defaultValue={centsToRubInput(product?.fullBottlePriceCents)} />
        <Field label="Остаток распива, мл" name="stockMl" type="number" defaultValue={product?.stockMl ?? 0} />
        <Field label="Остаток флаконов" name="stockBottles" type="number" defaultValue={product?.stockBottles ?? 0} />
        <Field label="Meta title" name="metaTitle" defaultValue={product?.metaTitle} />
        <Field label="Meta description" name="metaDescription" defaultValue={product?.metaDescription} />
        <ImageUpload defaultValue={product?.imageUrl || ""} />
        <Area label="История создания" name="history" defaultValue={product?.history} placeholder="Если подтверждённых данных нет — оставь пустым" />
        <Area label="Описание" name="description" defaultValue={product?.description} placeholder="Без выдуманных нот, стойкости и истории" />
      </div>

      <label className="flex items-center gap-3 rounded-2xl border border-graphite-100 bg-graphite-50 p-4 text-sm">
        <input type="checkbox" name="isPublished" defaultChecked={product?.isPublished ?? false} className="h-4 w-4" />
        Опубликовать товар
      </label>

      <button className="btn-primary w-full sm:w-fit">Сохранить товар</button>
    </form>
  );
}

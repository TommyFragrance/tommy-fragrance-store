import Link from "next/link";
import Image from "next/image";
import type { Brand, Product } from "@prisma/client";
import { formatRub } from "@/lib/utils";

type ProductWithBrand = Product & { brand: Brand };

export function ProductCard({ product }: { product: ProductWithBrand }) {
  const price = product.pricePerMlCents ? `от ${formatRub(product.pricePerMlCents)} / мл` : formatRub(product.fullBottlePriceCents);

  return (
    <Link href={`/catalog/${product.slug}`} className="group block overflow-hidden rounded-[2rem] border border-graphite-100 bg-white transition hover:-translate-y-1 hover:shadow-soft">
      <div className="relative aspect-[4/5] overflow-hidden bg-graphite-50">
        {product.imageUrl ? (
          <Image src={product.imageUrl} alt={`${product.brand.name} ${product.name}`} fill className="object-cover transition duration-700 group-hover:scale-105" />
        ) : (
          <div className="flex h-full items-center justify-center luxury-grid">
            <div className="text-center">
              <div className="text-xs uppercase tracking-luxury text-graphite-400">Original</div>
              <div className="mt-3 text-2xl font-semibold text-graphite-900">{product.brand.name}</div>
            </div>
          </div>
        )}
      </div>
      <div className="p-6">
        <div className="text-xs uppercase tracking-luxury text-graphite-400">{product.brand.name}</div>
        <h3 className="mt-2 text-xl font-semibold text-graphite-900">{product.name}</h3>
        <div className="mt-4 flex items-center justify-between gap-3">
          <span className="text-sm text-graphite-500">{product.concentration || "Концентрация не указана"}</span>
          <span className="text-sm font-semibold text-graphite-900">{price}</span>
        </div>
      </div>
    </Link>
  );
}

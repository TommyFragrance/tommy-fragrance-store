"use client";

import { useMemo, useState } from "react";
import type { Brand, Product } from "@prisma/client";
import { MessageCircle, Send } from "lucide-react";
import { buildTelegramOrderUrl, buildWhatsAppOrderUrl } from "@/lib/order";
import { formatRub } from "@/lib/utils";

type ProductWithBrand = Product & { brand: Brand };

type Option = {
  label: string;
  volumeMl: number | null;
  priceCents: number;
};

export function OrderActions({ product }: { product: ProductWithBrand }) {
  const options = useMemo<Option[]>(() => {
    const decants = (product.availableVolumesMl || [])
      .filter((ml) => product.pricePerMlCents && ml > 0)
      .map((ml) => ({
        label: `${ml} мл`,
        volumeMl: ml,
        priceCents: Number(product.pricePerMlCents) * ml
      }));

    const full = product.fullBottlePriceCents
      ? [{ label: product.fullBottleMl ? `Полный флакон ${product.fullBottleMl} мл` : "Полный флакон", volumeMl: product.fullBottleMl, priceCents: product.fullBottlePriceCents }]
      : [];

    return [...decants, ...full];
  }, [product]);

  const [selected, setSelected] = useState<Option | null>(options[0] || null);

  async function registerLead(channel: "TELEGRAM" | "WHATSAPP") {
    if (!selected) return;
    await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productSlug: product.slug,
        volumeLabel: selected.label,
        volumeMl: selected.volumeMl,
        priceCents: selected.priceCents,
        channel
      })
    }).catch(() => null);
  }

  if (!selected) {
    return (
      <div className="rounded-[2rem] border border-graphite-100 bg-graphite-50 p-6 text-sm text-graphite-500">
        Цена не указана. Добавьте цену за мл или стоимость полного флакона в админке.
      </div>
    );
  }

  const orderInput = {
    productName: product.name,
    brandName: product.brand.name,
    volumeLabel: selected.label,
    priceCents: selected.priceCents
  };

  return (
    <div className="rounded-[2rem] border border-graphite-100 bg-white p-6 shadow-soft">
      <div className="text-xs font-semibold uppercase tracking-luxury text-graphite-400">Выберите объём</div>
      <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
        {options.map((option) => (
          <button
            key={option.label}
            onClick={() => setSelected(option)}
            className={`rounded-full border px-3 py-2 text-sm transition ${selected.label === option.label ? "border-graphite-900 bg-graphite-900 text-white" : "border-graphite-200 bg-white text-graphite-700 hover:border-graphite-900"}`}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="mt-6 flex items-end justify-between border-t border-graphite-100 pt-5">
        <div>
          <div className="text-sm text-graphite-500">Стоимость</div>
          <div className="text-3xl font-semibold text-graphite-900">{formatRub(selected.priceCents)}</div>
        </div>
        <div className="text-right text-xs text-graphite-400">Цена пересчитана автоматически</div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <a
          href={buildTelegramOrderUrl(orderInput)}
          target="_blank"
          rel="noreferrer"
          onClick={() => registerLead("TELEGRAM")}
          className="btn-primary gap-2"
        >
          <Send size={16} /> Заказать в Telegram
        </a>
        <a
          href={buildWhatsAppOrderUrl(orderInput)}
          target="_blank"
          rel="noreferrer"
          onClick={() => registerLead("WHATSAPP")}
          className="btn-secondary gap-2"
        >
          <MessageCircle size={16} /> Заказать в WhatsApp
        </a>
      </div>
    </div>
  );
}

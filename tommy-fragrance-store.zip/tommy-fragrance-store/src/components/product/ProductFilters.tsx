import type { Brand } from "@prisma/client";

type Props = {
  filters: {
    brands: Brand[];
    genders: string[];
    concentrations: string[];
    types: string[];
    seasons: string[];
  };
  searchParams: Record<string, string | undefined>;
};

export function ProductFilters({ filters, searchParams }: Props) {
  return (
    <form className="grid gap-3 rounded-[2rem] border border-graphite-100 bg-graphite-50 p-4 md:grid-cols-2 lg:grid-cols-8" action="/catalog">
      <input name="q" defaultValue={searchParams.q} placeholder="Поиск по названию" className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900 lg:col-span-2" />
      <select name="brand" defaultValue={searchParams.brand || ""} className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900">
        <option value="">Бренд</option>
        {filters.brands.map((brand) => <option key={brand.id} value={brand.slug}>{brand.name}</option>)}
      </select>
      <select name="gender" defaultValue={searchParams.gender || ""} className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900">
        <option value="">Пол</option>
        {filters.genders.map((item) => <option key={item} value={item}>{item}</option>)}
      </select>
      <select name="season" defaultValue={searchParams.season || ""} className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900">
        <option value="">Сезон</option>
        {filters.seasons.map((item) => <option key={item} value={item}>{item}</option>)}
      </select>
      <select name="concentration" defaultValue={searchParams.concentration || ""} className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900">
        <option value="">Концентрация</option>
        {filters.concentrations.map((item) => <option key={item} value={item}>{item}</option>)}
      </select>
      <select name="type" defaultValue={searchParams.type || ""} className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900">
        <option value="">Тип</option>
        {filters.types.map((item) => <option key={item} value={item}>{item}</option>)}
      </select>
      <input name="min" defaultValue={searchParams.min} placeholder="Цена от" className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900" />
      <input name="max" defaultValue={searchParams.max} placeholder="Цена до" className="rounded-full border border-graphite-200 bg-white px-4 py-3 text-sm outline-none focus:border-graphite-900" />
      <button className="rounded-full bg-graphite-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-graphite-700">Найти</button>
    </form>
  );
}

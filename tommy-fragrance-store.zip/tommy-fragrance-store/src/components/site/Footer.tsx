import Link from "next/link";
import { nav, site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="border-t border-graphite-100 bg-graphite-900 text-white">
      <div className="container-lux grid gap-10 py-14 md:grid-cols-[1.2fr_.8fr_.8fr]">
        <div>
          <div className="text-xl font-semibold uppercase tracking-[0.28em]">Tommy Fragrance</div>
          <p className="mt-5 max-w-md text-sm leading-7 text-graphite-300">
            Экспертный бутик оригинальной парфюмерии. Полные флаконы и распив от 1 мл. Бесплатная доставка по России.
          </p>
        </div>
        <div>
          <div className="text-xs font-semibold uppercase tracking-luxury text-graphite-400">Навигация</div>
          <div className="mt-5 grid gap-3">
            {nav.map((item) => (
              <Link key={item.href} href={item.href} className="text-sm text-graphite-300 hover:text-white">
                {item.label}
              </Link>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs font-semibold uppercase tracking-luxury text-graphite-400">Связь</div>
          <div className="mt-5 grid gap-3 text-sm text-graphite-300">
            <a href={`https://t.me/${site.telegramUsername}`} target="_blank" rel="noreferrer">Telegram: @{site.telegramUsername}</a>
            <a href={`https://wa.me/${site.whatsappPhone}`} target="_blank" rel="noreferrer">WhatsApp</a>
            <a href={`https://instagram.com/${site.instagramUsername}`} target="_blank" rel="noreferrer">Instagram: @{site.instagramUsername}</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-xs text-graphite-500">
        © {new Date().getFullYear()} Tommy Fragrance. Только оригинальная продукция.
      </div>
    </footer>
  );
}

import Link from "next/link";
import { Menu } from "lucide-react";
import { nav, site } from "@/lib/site";

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-graphite-100 bg-white/90 backdrop-blur-xl">
      <div className="container-lux flex h-20 items-center justify-between">
        <Link href="/" className="group">
          <div className="text-lg font-semibold uppercase tracking-[0.28em] text-graphite-900">Tommy</div>
          <div className="text-[10px] uppercase tracking-[0.42em] text-graphite-400">Fragrance</div>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm text-graphite-600 transition hover:text-graphite-900">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link href="/catalog" className="hidden rounded-full bg-graphite-900 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-graphite-700 sm:inline-flex">
            Смотреть каталог
          </Link>
          <a href={`https://t.me/${site.telegramUsername}`} target="_blank" rel="noreferrer" className="hidden rounded-full border border-graphite-200 px-5 py-2.5 text-sm font-medium text-graphite-900 transition hover:border-graphite-900 sm:inline-flex">
            Telegram
          </a>
          <button aria-label="Открыть меню" className="inline-flex rounded-full border border-graphite-200 p-3 lg:hidden">
            <Menu size={18} />
          </button>
        </div>
      </div>
    </header>
  );
}

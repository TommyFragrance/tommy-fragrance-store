export const site = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || "Tommy Fragrance",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  telegramUsername: process.env.NEXT_PUBLIC_TELEGRAM_USERNAME || "axmtommy",
  telegramChannel: process.env.NEXT_PUBLIC_TELEGRAM_CHANNEL || "tommy.fragrance",
  whatsappPhone: process.env.NEXT_PUBLIC_WHATSAPP_PHONE || "79389110115",
  instagramUsername: process.env.NEXT_PUBLIC_INSTAGRAM_USERNAME || "tommy.fragrance",
  description:
    "Tommy Fragrance — экспертный бутик оригинальной парфюмерии. Полные флаконы и распив от 1 мл. Бесплатная доставка по России."
};

export const nav = [
  { href: "/catalog", label: "Каталог" },
  { href: "/brands", label: "Бренды" },
  { href: "/decants", label: "Распивы" },
  { href: "/aroma-selection", label: "Подбор" },
  { href: "/about", label: "О нас" },
  { href: "/contacts", label: "Контакты" }
];

import { site } from "@/lib/site";
import { formatRub, normalizePhone } from "@/lib/utils";

export type OrderMessageInput = {
  productName: string;
  brandName: string;
  volumeLabel: string;
  priceCents: number;
};

export function buildOrderText(input: OrderMessageInput) {
  return `Здравствуйте.\n\nМеня интересует:\n${input.brandName} ${input.productName}\n\nОбъем:\n${input.volumeLabel}\n\nСтоимость:\n${formatRub(input.priceCents)}`;
}

export function buildTelegramOrderUrl(input: OrderMessageInput) {
  const text = buildOrderText(input);
  return `https://t.me/share/url?url=${encodeURIComponent(site.url)}&text=${encodeURIComponent(text)}`;
}

export function buildTelegramProfileUrl() {
  return `https://t.me/${site.telegramUsername.replace("@", "")}`;
}

export function buildWhatsAppOrderUrl(input: OrderMessageInput) {
  const text = buildOrderText(input);
  return `https://wa.me/${normalizePhone(site.whatsappPhone)}?text=${encodeURIComponent(text)}`;
}

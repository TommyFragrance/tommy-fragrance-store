import { clsx, type ClassValue } from "clsx";
import slugify from "slugify";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

export function formatRub(cents?: number | null) {
  if (typeof cents !== "number") return "Цена по запросу";
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0
  }).format(Math.round(cents / 100));
}

export function toSlug(value: string) {
  return slugify(value, { lower: true, strict: true, locale: "ru" });
}

export function splitList(value: FormDataEntryValue | null): string[] {
  if (!value) return [];
  return String(value)
    .split(/[,;\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

export function parseIntOrNull(value: FormDataEntryValue | null): number | null {
  if (value === null || value === "") return null;
  const n = Number.parseInt(String(value), 10);
  return Number.isFinite(n) ? n : null;
}

export function rubToCents(value: FormDataEntryValue | null): number | null {
  if (value === null || value === "") return null;
  const cleaned = String(value).replace(/\s/g, "").replace(",", ".");
  const n = Number.parseFloat(cleaned);
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}

export function centsToRubInput(value?: number | null) {
  if (typeof value !== "number") return "";
  return String(Math.round(value / 100));
}

export function normalizePhone(phone: string) {
  return phone.replace(/\D/g, "");
}

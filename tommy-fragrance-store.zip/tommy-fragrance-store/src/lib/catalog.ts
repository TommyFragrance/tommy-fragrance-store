import { prisma } from "@/lib/prisma";

export type CatalogSearchParams = {
  q?: string;
  brand?: string;
  gender?: string;
  season?: string;
  concentration?: string;
  type?: string;
  min?: string;
  max?: string;
};

export async function getCatalogProducts(searchParams: CatalogSearchParams = {}) {
  const min = searchParams.min ? Number(searchParams.min) * 100 : undefined;
  const max = searchParams.max ? Number(searchParams.max) * 100 : undefined;

  return prisma.product.findMany({
    where: {
      isPublished: true,
      ...(searchParams.q
        ? {
            OR: [
              { name: { contains: searchParams.q, mode: "insensitive" } },
              { brand: { name: { contains: searchParams.q, mode: "insensitive" } } }
            ]
          }
        : {}),
      ...(searchParams.brand ? { brand: { slug: searchParams.brand } } : {}),
      ...(searchParams.gender ? { gender: { equals: searchParams.gender, mode: "insensitive" } } : {}),
      ...(searchParams.season ? { seasonality: { has: searchParams.season } } : {}),
      ...(searchParams.concentration ? { concentration: { equals: searchParams.concentration, mode: "insensitive" } } : {}),
      ...(searchParams.type ? { aromaType: { contains: searchParams.type, mode: "insensitive" } } : {}),
      ...(min || max
        ? {
            OR: [
              { fullBottlePriceCents: { ...(min ? { gte: min } : {}), ...(max ? { lte: max } : {}) } },
              { pricePerMlCents: { ...(min ? { gte: min } : {}), ...(max ? { lte: max } : {}) } }
            ]
          }
        : {})
    },
    include: { brand: true },
    orderBy: [{ brand: { name: "asc" } }, { name: "asc" }]
  });
}

export async function getProductBySlug(slug: string) {
  return prisma.product.findFirst({
    where: { slug, isPublished: true },
    include: { brand: true }
  });
}

export async function getAdminProductById(id: string) {
  return prisma.product.findUnique({
    where: { id },
    include: { brand: true }
  });
}

export async function getBrands() {
  return prisma.brand.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: "asc" }
  });
}

export async function getBrandBySlug(slug: string) {
  return prisma.brand.findUnique({
    where: { slug },
    include: {
      products: {
        where: { isPublished: true },
        include: { brand: true },
        orderBy: { name: "asc" }
      }
    }
  });
}

export async function getFilters() {
  const [brands, products] = await Promise.all([
    prisma.brand.findMany({ orderBy: { name: "asc" } }),
    prisma.product.findMany({
      where: { isPublished: true },
      select: { gender: true, concentration: true, aromaType: true, seasonality: true }
    })
  ]);

  const genders = [...new Set(products.map((p) => p.gender).filter(Boolean) as string[])].sort();
  const concentrations = [...new Set(products.map((p) => p.concentration).filter(Boolean) as string[])].sort();
  const types = [...new Set(products.map((p) => p.aromaType).filter(Boolean) as string[])].sort();
  const seasons = [...new Set(products.flatMap((p) => p.seasonality).filter(Boolean))].sort();

  return { brands, genders, concentrations, types, seasons };
}
